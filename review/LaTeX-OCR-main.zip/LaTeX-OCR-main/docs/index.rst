.. LaTeX-OCR documentation master file, created by
   sphinx-quickstart on Sun May  1 16:39:27 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to LaTeX-OCR's documentation!
=====================================

.. |ico| image:: https://img.shields.io/badge/LaTeX--OCR-visit-a?style=social&logo=github
   :target: https://github.com/lukas-blecher/LaTeX-OCR
This is the documentation for LaTeX-OCR |ico|. The goal of this project is to find a corresponding LaTeX code for a given image of an equation.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   pix2tex


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

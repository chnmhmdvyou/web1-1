Directly taken from https://github.com/harvardnlp/im2markup
